This folder contains the [nanosvg](https://github.com/memononen/nanosvg) headers (commit c1f6e20, downloaded in March 2019). Only minor changes were made to get rid of compiler warnings.
